// dashboard.js – shared dashboard utilities (kosong, sudah di main.js)
// File ini dipertahankan untuk konsistensi import
