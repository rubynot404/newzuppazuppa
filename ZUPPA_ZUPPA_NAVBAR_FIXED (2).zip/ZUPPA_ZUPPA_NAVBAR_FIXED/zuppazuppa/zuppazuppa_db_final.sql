-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Bulan Mei 2026 pada 16.45
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zuppazuppa_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `konten`
--

CREATE TABLE `konten` (
  `id_konten` int(11) NOT NULL,
  `judul` varchar(300) NOT NULL,
  `isi` text DEFAULT NULL,
  `gambar` varchar(500) DEFAULT NULL,
  `tipe` enum('hero','promo','info','why_us','about_us') NOT NULL DEFAULT 'info',
  `is_aktif` tinyint(1) NOT NULL DEFAULT 1,
  `id_user` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `konten`
--

INSERT INTO `konten` (`id_konten`, `judul`, `isi`, `gambar`, `tipe`, `is_aktif`, `id_user`, `created_at`, `updated_at`) VALUES
(1, 'Selamat Datang di ZuppaZuppa', 'Nikmati kelezatan Zuppa Soup terbaik dengan bahan-bahan pilihan berkualitas tinggi. Kami hadir untuk memanjakan lidah Anda.', NULL, 'hero', 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(2, 'Kualitas Terjamin', 'Bahan-bahan segar dipilih setiap hari untuk menjaga kualitas terbaik.', NULL, 'why_us', 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(3, 'Harga Terjangkau', 'Menikmati makanan lezat tidak harus mahal. Kami hadir dengan harga yang bersahabat.', NULL, 'why_us', 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(4, 'Rasa Otentik', 'Resep turun-temurun yang telah teruji dan dicintai banyak pelanggan.', NULL, 'why_us', 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_aktivitas`
--

CREATE TABLE `log_aktivitas` (
  `id_log` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `aktivitas` varchar(500) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `log_aktivitas`
--

INSERT INTO `log_aktivitas` (`id_log`, `id_user`, `aktivitas`, `waktu`, `ip_address`) VALUES
(1, 1, 'Login berhasil (role: admin)', '2026-05-08 08:10:09', '::1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_user` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff_marketing') NOT NULL,
  `kode_khusus` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_user`, `username`, `password`, `role`, `kode_khusus`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2b$12$7mmJ6SOnz3pn1H5pk2BZDeFR7P0FfQiTWaox2h6a9WxZpyLHz5JVW', 'admin', 'ZUPPA2025', '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(2, 'staff_mkt_1', '$2b$12$31quACU/B9k4ejyb.9r6ZePuIWpD8Td1GTcXNrpd9aaahOal.0v0S', 'staff_marketing', NULL, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(3, 'staff_mkt_2', '$2b$12$Q9dgZzojY0Txk0poYldIl.6NfBuFsLYQFsRNTAo0Nqh/1IWgGYZmy', 'staff_marketing', NULL, '2026-05-08 08:07:38', '2026-05-08 08:07:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(11) NOT NULL,
  `nama_pelanggan` varchar(200) NOT NULL,
  `no_wa` varchar(20) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL DEFAULT 1,
  `total_harga` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('masuk','diproses','selesai','dibatalkan') NOT NULL DEFAULT 'masuk',
  `catatan` text DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(500) DEFAULT NULL,
  `harga` decimal(12,2) NOT NULL DEFAULT 0.00,
  `kategori` varchar(100) DEFAULT NULL,
  `is_top_menu` tinyint(1) NOT NULL DEFAULT 0,
  `is_aktif` tinyint(1) NOT NULL DEFAULT 1,
  `id_user` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `nama`, `deskripsi`, `gambar`, `harga`, `kategori`, `is_top_menu`, `is_aktif`, `id_user`, `created_at`, `updated_at`) VALUES
(1, 'Zuppa Soup Original', 'Soup Cream dengan Topping Irisan Ayam, Jagung dan Daging Asap Yang Creamy', NULL, 22000.00, 'Soup', 1, 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(2, 'Zuppa Soup Spesial', 'Soup Cream dengan Topping Irisan Ayam, Jagung dan Daging Asap Yang Creamy', NULL, 25000.00, 'Soup', 1, 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(3, 'Pasta Carbonara', 'Pasta creamy dengan saus carbonara dan daging asap pilihan', NULL, 28000.00, 'Pasta', 0, 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(4, 'Pasta Bolognese', 'Pasta dengan saus daging cincang khas Italia yang gurih', NULL, 28000.00, 'Pasta', 0, 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(5, 'Macaroni Schotel', 'Macaroni panggang dengan isian daging dan keju', NULL, 25000.00, 'Snack', 0, 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38'),
(6, 'Spaghetti Brulee', 'Spaghetti dengan teknik brulee yang unik dan lezat', NULL, 30000.00, 'Pasta', 0, 1, 1, '2026-05-08 08:07:38', '2026-05-08 08:07:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `testimoni`
--

CREATE TABLE `testimoni` (
  `id_testimoni` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `isi` text NOT NULL,
  `bintang` tinyint(4) NOT NULL DEFAULT 5 CHECK (`bintang` between 1 and 5),
  `platform` varchar(100) NOT NULL DEFAULT 'Google Maps',
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `testimoni`
--

INSERT INTO `testimoni` (`id_testimoni`, `nama`, `isi`, `bintang`, `platform`, `tanggal`, `id_user`) VALUES
(1, 'Budi Santoso', 'Zuppa Soup-nya enak banget! Creamy dan gurih, cocok untuk semua kalangan.', 5, 'Google Maps', '2026-05-08 08:07:39', 1),
(2, 'Siti Rahayu', 'Harganya terjangkau, porsinya besar. Pasti balik lagi!', 5, 'GoFood', '2026-05-08 08:07:39', 1),
(3, 'Andi Pratama', 'Pelayanannya ramah dan makanannya cepat disajikan. Recommended!', 4, 'GrabFood', '2026-05-08 08:07:39', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `konten`
--
ALTER TABLE `konten`
  ADD PRIMARY KEY (`id_konten`),
  ADD KEY `fk_konten_user` (`id_user`),
  ADD KEY `idx_konten_tipe` (`tipe`);

--
-- Indeks untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `idx_log_waktu` (`waktu`),
  ADD KEY `idx_log_user` (`id_user`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `fk_pesanan_produk` (`id_produk`),
  ADD KEY `idx_pesanan_status` (`status`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD KEY `fk_produk_user` (`id_user`),
  ADD KEY `idx_produk_kategori` (`kategori`),
  ADD KEY `idx_produk_is_aktif` (`is_aktif`),
  ADD KEY `idx_produk_is_top` (`is_top_menu`);

--
-- Indeks untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  ADD PRIMARY KEY (`id_testimoni`),
  ADD KEY `fk_testimoni_moderator` (`id_user`),
  ADD KEY `idx_testimoni_status` (`status`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `konten`
--
ALTER TABLE `konten`
  MODIFY `id_konten` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  MODIFY `id_testimoni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `konten`
--
ALTER TABLE `konten`
  ADD CONSTRAINT `fk_konten_user` FOREIGN KEY (`id_user`) REFERENCES `pengguna` (`id_user`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD CONSTRAINT `fk_log_user` FOREIGN KEY (`id_user`) REFERENCES `pengguna` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `fk_pesanan_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `fk_produk_user` FOREIGN KEY (`id_user`) REFERENCES `pengguna` (`id_user`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  ADD CONSTRAINT `fk_testimoni_moderator` FOREIGN KEY (`id_user`) REFERENCES `pengguna` (`id_user`) ON DELETE SET NULL ON UPDATE CASCADE;
-- Tambah nilai about_us ke enum tipe konten (jalankan jika database sudah ada)
-- ALTER TABLE `konten` MODIFY `tipe` enum('hero','promo','info','why_us','about_us') NOT NULL DEFAULT 'info';

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
